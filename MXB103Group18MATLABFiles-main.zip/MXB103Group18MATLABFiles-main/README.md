# MXB103Group18MATLABFiles


N.B.
Write `constants` to load the variable from `constants.m`
into the current workspace.